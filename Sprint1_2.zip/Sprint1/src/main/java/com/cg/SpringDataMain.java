package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataMain 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(SpringDataMain.class,args);
		System.out.println("...Server  started...");

	}

}
