package com.cg.spc.entities;

public enum ConcernParty {
TEACHER,ACCOUNTANT,PRINCIPAL,TRANSPORTOFFICER,CATERER;
	
}
