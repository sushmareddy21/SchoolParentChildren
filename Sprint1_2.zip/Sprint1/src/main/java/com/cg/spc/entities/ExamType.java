package com.cg.spc.entities;

public enum ExamType 
{ 
	MCQ,DESCRIPTIVE,ANALYTICAL;
	
}
