package com.cg.spc.exception;

public class ExamIdNotFoundException extends RuntimeException 
{
	public ExamIdNotFoundException(String msg)
	{
		super(msg);
	}
}
