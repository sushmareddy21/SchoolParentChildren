package com.cg.util;

import org.springframework.stereotype.Component;

@Component
public class ParentUtil
{
   
}
